
import 'package:flutter/material.dart';
void main() => runApp(MyApp());
class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final appTitle = 'add new paitinet';
    return MaterialApp(
      title: appTitle,
      home: Scaffold(
        appBar: AppBar(
          title: Text(appTitle),
          centerTitle: true,
          actions: [
            IconButton(
              alignment: AlignmentDirectional.topStart,
              icon: Icon(Icons.arrow_back),
              onPressed: () {
                Navigator.pop(context);
              },
            ),
          
      ],
        ),
        body: MyCustomForm(),
      ),
    );
  }
}
class MyCustomForm extends StatefulWidget {
  @override
  MyCustomFormState createState() {
    return MyCustomFormState();
  }
}

class MyCustomFormState extends State<MyCustomForm> {

  final _formKey = GlobalKey<FormState>();
  @override
  Widget build(BuildContext context) {

    return Form(
      key: _formKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          TextFormField(
            decoration: const InputDecoration(
              hintText: 'Enter your name',
              labelText: 'First-Name',
            ),
          ),
          TextFormField(
            decoration: const InputDecoration(
              hintText: 'Enter your name  ',
              labelText: 'last-Name',
            ),
          ),
          TextFormField(
            decoration: const InputDecoration(
              hintText: 'Enter your id number',
              labelText: 'ID',
            ),
          ),
          TextFormField(
            decoration: const InputDecoration(
              hintText: 'Enter a phone number',
              labelText: 'Phone',
            ),
          ),
          TextFormField(
            decoration: const InputDecoration(
              hintText: 'Enter your age',
              labelText: 'Age',
            ),
          ),
          TextFormField(
            decoration: const InputDecoration(
              hintText: 'Enter your date of birth',
              labelText: 'Birthdate',
            ),
          ),

          TextFormField(
            decoration: const InputDecoration(
              hintText: 'Enter your city',
              labelText: 'City',
            ),
          ),

          TextFormField(
            decoration: const InputDecoration(
              hintText: 'Enter your sex',
              labelText: 'Sex',
            ),
          ),
          TextFormField(
            decoration: const InputDecoration(
              hintText: 'Do you do drugs',
              labelText: 'Drug addict',
            ),
          ),
          TextFormField(
            decoration: const InputDecoration(
              hintText: 'Do you do drinks',
              labelText: 'Driniks alcohol',
            ),
          ),

          TextFormField(
            decoration: const InputDecoration(
              hintText: 'Enter a nmber bed',
              labelText: 'Bed number',
            ),
          ),
          TextFormField(
            decoration: const InputDecoration(
              hintText: 'Enter a nmber room',
              labelText: 'Room number',
            ),
          ),

          TextFormField(
            decoration: const InputDecoration(
              hintText: 'Enter your department',
              labelText: 'Department',
            ),
          ),
          TextFormField(
            decoration: const InputDecoration(
              hintText: 'Enter a Corona disease',
              labelText: 'Corona disease',
            ),
          ),

          new Container(
              padding: const EdgeInsets.only(left: 150.0, top: 40.0),
              child: new ElevatedButton(onPressed: null,
                child: const Text('Save'),)),
        ],
      ),
    );
  }
}