import 'package:flutter/material.dart';


class Home1 extends StatefulWidget {
  const Home1({super.key});

  @override
  State<Home1> createState() => _Home1State();
}

class _Home1State extends State<Home1> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: Colors.grey[800],
        title: Text(
          "List of user",
          style: TextStyle(
            color:Colors.white, 
            fontSize:20,        
             ),

        ),
      actions: [
            IconButton(
              alignment: AlignmentDirectional.topStart,
              icon: Icon(Icons.search),
              onPressed: () {
                Navigator.pop(context);
              },
            ),
          
      ],
      ),
const List<Item> _items = [
 Item(
 name: 'Spinach Pizza',
 totalPriceCents: 1299,
 uid: '1',
 
 Item(
 name: 'Veggie Delight',
 totalPriceCents: 799,
 uid: '2',
 )
 Item(
 name: 'Chicken Parmesan',
 totalPriceCents: 1499,
 uid: '3',
 
 ),
];



      floatingActionButton: FloatingActionButton(
        onPressed:() => {},
      child: Icon(Icons.add),) ,
    );
  }
}