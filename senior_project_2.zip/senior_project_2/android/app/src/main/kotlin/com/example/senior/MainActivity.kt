package com.example.senior

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
